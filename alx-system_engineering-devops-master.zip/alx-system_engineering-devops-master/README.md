dev opsreadme
