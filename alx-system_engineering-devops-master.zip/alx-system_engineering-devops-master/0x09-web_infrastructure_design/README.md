0x09. Web infrastructure design
