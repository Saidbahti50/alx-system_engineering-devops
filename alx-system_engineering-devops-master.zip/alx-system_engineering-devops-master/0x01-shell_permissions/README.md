absolute path2
