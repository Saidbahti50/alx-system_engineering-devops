loops and condition devops
